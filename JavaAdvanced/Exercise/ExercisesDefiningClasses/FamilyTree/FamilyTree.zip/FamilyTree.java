package ExercisesDefiningClasses.FamilyTree;

import java.util.ArrayList;
import java.util.List;

public class FamilyTree {
    String name;
    String birthday;
    List<FamilyTree> parents;
    List<FamilyTree> children;

    public FamilyTree(String name, String birthday) {
        this.name = name;
        this.birthday = birthday;
        this.parents = new ArrayList<>();
        this.children = new ArrayList<>();
    }
    public FamilyTree() {

    }

    public String getName() {
        return name;
    }

    public String getBirthday() {
        return birthday;
    }

    public List<FamilyTree> getParents() {
        return parents;
    }

    public List<FamilyTree> getChildren() {
        return children;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public void setParents(List<FamilyTree> parents) {
        this.parents = parents;
    }

    public void setChildren(List<FamilyTree> children) {
        this.children = children;
    }

    @Override
    public String toString() {
        return String.format("%s %s", this.name, this.birthday);

    }
}
